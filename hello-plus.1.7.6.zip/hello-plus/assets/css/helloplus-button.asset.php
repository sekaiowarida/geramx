<?php return array('dependencies' => array(), 'version' => '96600407dbdfddc0b40e');
