<?php return array('dependencies' => array(), 'version' => 'c6e0551c47e11a2884a9');
