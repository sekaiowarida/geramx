<?php return array('dependencies' => array(), 'version' => 'da6a2854cc2adc70d6e3');
