<?php return array('dependencies' => array(), 'version' => '52537ebfb4d7fddbdb0b');
