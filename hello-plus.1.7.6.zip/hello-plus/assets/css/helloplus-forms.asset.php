<?php return array('dependencies' => array(), 'version' => '50d3bd11572161a757a0');
