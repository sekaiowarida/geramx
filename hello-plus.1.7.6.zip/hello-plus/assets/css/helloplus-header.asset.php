<?php return array('dependencies' => array(), 'version' => '8abd069b358f60eb2237');
