<?php return array('dependencies' => array(), 'version' => '246a4978c9cb3bf396d5');
