<?php return array('dependencies' => array(), 'version' => '147afc99ce9edde022ac');
