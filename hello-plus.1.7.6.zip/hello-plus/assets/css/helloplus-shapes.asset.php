<?php return array('dependencies' => array(), 'version' => '9a780d7e25db4ad335f0');
