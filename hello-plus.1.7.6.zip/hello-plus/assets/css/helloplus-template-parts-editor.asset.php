<?php return array('dependencies' => array(), 'version' => '20dc58bf9f7a720d6af1');
