<?php return array('dependencies' => array(), 'version' => 'fba6c549198ef2b9d393');
