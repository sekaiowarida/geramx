<?php return array('dependencies' => array(), 'version' => '0458f8757ee8dc44628c');
