<?php return array('dependencies' => array(), 'version' => '59e0ea7d881c35cabad1');
