const ControlChooseItemViewImg = elementor.modules.controls.Choose.extend( {} );

export default ControlChooseItemViewImg;
