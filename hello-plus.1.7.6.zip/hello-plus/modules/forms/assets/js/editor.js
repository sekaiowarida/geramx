import FormsModule from './editor/module';

const HelloPlusForms = new FormsModule();

window.helloPlusForms = HelloPlusForms;
