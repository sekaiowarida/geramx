<?php return array('dependencies' => array(), 'version' => 'fbb750fd312778403036');
