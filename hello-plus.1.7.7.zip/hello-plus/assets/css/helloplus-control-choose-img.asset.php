<?php return array('dependencies' => array(), 'version' => '757f384f546ef53cc75e');
