<?php return array('dependencies' => array(), 'version' => 'b1d6a551a7f2fed7525c');
