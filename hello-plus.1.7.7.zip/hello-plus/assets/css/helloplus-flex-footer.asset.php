<?php return array('dependencies' => array(), 'version' => 'a02f1dafed5588b001c8');
