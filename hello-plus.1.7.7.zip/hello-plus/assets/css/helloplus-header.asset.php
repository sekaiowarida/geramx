<?php return array('dependencies' => array(), 'version' => '04404d8f2eb72e6f0b69');
