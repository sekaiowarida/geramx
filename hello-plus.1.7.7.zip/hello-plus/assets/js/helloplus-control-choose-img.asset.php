<?php return array('dependencies' => array(), 'version' => '48fa5cf51c3182a31cad');
