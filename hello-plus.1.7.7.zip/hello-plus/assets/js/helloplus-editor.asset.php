<?php return array('dependencies' => array('wp-i18n'), 'version' => '51a55233af2d64142079');
