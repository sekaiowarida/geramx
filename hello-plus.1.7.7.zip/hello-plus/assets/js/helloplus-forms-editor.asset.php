<?php return array('dependencies' => array(), 'version' => '08cb1751ab4da51480df');
