<?php return array('dependencies' => array(), 'version' => 'a2ce12992357ff748a1c');
