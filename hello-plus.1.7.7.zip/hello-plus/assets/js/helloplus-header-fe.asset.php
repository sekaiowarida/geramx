<?php return array('dependencies' => array(), 'version' => '334f79daa9a9a2bc5005');
