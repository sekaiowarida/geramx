<?php return array('dependencies' => array(), 'version' => 'df8cc159b9abad59fbd2');
