import ContentModule from './editor/module';

const HelloPlusContent = new ContentModule();

window.helloPlusContent = HelloPlusContent;
