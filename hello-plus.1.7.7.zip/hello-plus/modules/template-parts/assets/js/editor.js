import TemplatesModule from './editor/module';

const HelloPlusTemplates = new TemplatesModule();

window.helloPlusTemplates = HelloPlusTemplates;
